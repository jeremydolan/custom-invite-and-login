<?php


class Invitation_Based_Registrations_Activator {

	public static function activate() {

	}

}
