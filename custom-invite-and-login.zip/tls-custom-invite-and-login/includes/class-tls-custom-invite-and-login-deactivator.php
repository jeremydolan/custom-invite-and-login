<?php


class Invitation_Based_Registrations_Deactivator {


	public static function deactivate() {

	}

}
